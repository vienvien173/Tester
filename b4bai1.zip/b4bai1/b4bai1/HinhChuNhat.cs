﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace buoi4
{
    public class HinhChuNhat
    {
        private Diem topLeft;
        private Diem bottomRight;

        public HinhChuNhat(Diem topLeft, Diem bottomRight)
        {
            if (topLeft.X >= bottomRight.X || topLeft.Y <= bottomRight.Y)
                throw new ArgumentException("Invalid Rectangle");

            this.topLeft = topLeft;
            this.bottomRight = bottomRight;
        }

        public int DienTich()
        {
            int width = bottomRight.X - topLeft.X;
            int height = topLeft.Y - bottomRight.Y;

            return width * height;
        }

        public bool GiaoNhau(HinhChuNhat other)
        {
            if (this.bottomRight.X <= other.topLeft.X ||
                other.bottomRight.X <= this.topLeft.X ||
                this.topLeft.Y <= other.bottomRight.Y ||
                other.topLeft.Y <= this.bottomRight.Y)
            {
                return false;
            }

            return true;
        }
    }
}
