﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using buoi4;
namespace test1
{
    [TestClass]
    public class UnitTestElectricBill
    {
        [TestMethod]
        public void TestBac1()
        {
            double result = ElectricBill.TinhTienDien(30);
            Assert.AreEqual(30 * 1678, result);
        }

        [TestMethod]
        public void TestBac2()
        {
            double result = ElectricBill.TinhTienDien(70);
            double expected = 50 * 1678 + 20 * 1734;
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void TestBac3()
        {
            double result = ElectricBill.TinhTienDien(150);
            double expected = 50 * 1678 + 50 * 1734 + 50 * 2014;
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        public void TestBac4()
        {
            double result = ElectricBill.TinhTienDien(250);
            double expected = 50 * 1678 + 50 * 1734 + 100 * 2014 + 50 * 2536;
            Assert.AreEqual(expected, result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestSoKwhAm()
        {
            ElectricBill.TinhTienDien(-10);
        }
    }
}
