﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using buoi4;
namespace test1
{
    [TestClass]
    public class UnitTestRadix
    {
        [TestMethod]
        public void TestConvertToBinary()
        {
            Radix r = new Radix(10);
            string result = r.ConvertDecimalToAnother(2);
            Assert.AreEqual("1010", result);
        }

        [TestMethod]
        public void TestConvertToOctal()
        {
            Radix r = new Radix(15);
            string result = r.ConvertDecimalToAnother(8);
            Assert.AreEqual("17", result);
        }

        [TestMethod]
        public void TestConvertToHex()
        {
            Radix r = new Radix(31);
            string result = r.ConvertDecimalToAnother(16);
            Assert.AreEqual("1F", result);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestNegativeNumber()
        {
            Radix r = new Radix(-5);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestInvalidRadix()
        {
            Radix r = new Radix(10);
            r.ConvertDecimalToAnother(20);
        }
    }
}
