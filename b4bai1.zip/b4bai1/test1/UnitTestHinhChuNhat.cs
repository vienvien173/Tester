﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using buoi4;

namespace test1
{
    [TestClass]
    public class UnitTestHinhChuNhat
    {
        [TestMethod]
        public void TestDienTich()
        {
            Diem tl = new Diem(0, 10);
            Diem br = new Diem(5, 0);

            HinhChuNhat hcn = new HinhChuNhat(tl, br);

            Assert.AreEqual(50, hcn.DienTich());
        }

        [TestMethod]
        public void TestHaiHinhGiaoNhau()
        {
            HinhChuNhat h1 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            HinhChuNhat h2 = new HinhChuNhat(new Diem(3, 8), new Diem(8, 2));

            Assert.IsTrue(h1.GiaoNhau(h2));
        }

        [TestMethod]
        public void TestHaiHinhKhongGiaoNhau()
        {
            HinhChuNhat h1 = new HinhChuNhat(new Diem(0, 10), new Diem(5, 0));
            HinhChuNhat h2 = new HinhChuNhat(new Diem(6, 10), new Diem(10, 0));

            Assert.IsFalse(h1.GiaoNhau(h2));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestTaoHinhKhongHopLe()
        {
            Diem tl = new Diem(5, 0);
            Diem br = new Diem(0, 10);

            HinhChuNhat h = new HinhChuNhat(tl, br);
        }
    }
}
