﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using buoi4;
namespace test1
{
    [TestClass]
    public class UnitTestPrime
    {
        [TestMethod]
        public void TestPrimeNumber()
        {
            bool result = PrimeUtils.IsPrime(7);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestNonPrimeNumber()
        {
            bool result = PrimeUtils.IsPrime(10);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TestNumberLessThanTwo()
        {
            bool result = PrimeUtils.IsPrime(1);
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TestPrimeTwo()
        {
            bool result = PrimeUtils.IsPrime(2);
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TestPrimeLarge()
        {
            bool result = PrimeUtils.IsPrime(29);
            Assert.IsTrue(result);
        }
    }
}
