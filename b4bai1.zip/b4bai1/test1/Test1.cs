﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using buoi4;
namespace test1
{
    [TestClass]
    public sealed class Test1
    {
        [TestMethod]
        public void TestPowerWithZeroExponent()
        {
            double result = MathUtils.Power(5, 0);
            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        public void TestPowerWithPositiveExponent()
        {
            double result = MathUtils.Power(2, 3);
            Assert.AreEqual(8.0, result);
        }

        [TestMethod]
        public void TestPowerWithNegativeExponent()
        {
            double result = MathUtils.Power(2, -2);
            Assert.AreEqual(0.25, result);
        }

        [TestMethod]
        public void TestPowerWithBaseZero()
        {
            double result = MathUtils.Power(0, 5);
            Assert.AreEqual(0.0, result);
        }

        [TestMethod]
        public void TestPowerWithBaseOne()
        {
            double result = MathUtils.Power(1, 10);
            Assert.AreEqual(1.0, result);
        }

        [TestMethod]
        public void TestPowerWithNegativeBase()
        {
            double result = MathUtils.Power(-2, 3);
            Assert.AreEqual(-8.0, result);
        }
    }
}
